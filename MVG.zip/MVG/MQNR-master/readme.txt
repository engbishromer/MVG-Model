Copyright (c) 2020 The Ningbo University
All rights reserved.

Permission is hereby granted, without written agreement and without license or royalty fees, to use, copy, modify, 
and distribute this code (the source files) and its documentation for any purpose, provided that the copyright notice 
in its entirety appear in all copies of this code, and the original source of this code, Ningbo University, is acknowledged in any publication that reports research using this code. 

The research is to be cited in the bibliography as:
[1] Xiangchao Meng, Kedi Bao, Bingzhong Zhou, Feng Shao, Weiwei Sun and Shutao Li. "A Blind Full Resolution Quality 
Evaluation Method for Pansharpening", Accepted, IEEE Transactions on Geoscience and Remote Sensing.

Author  : Kedi Bao
The authors are with the Faculty of Information Science and Engineering, Ningbo University, Ningbo 315211, China
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

You can change this program as you like and use it anywhere, but please
refer to its original source (cite our paper).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

the large remote sensing image dataset form "A Large-Scale Remote Sensing Database for Subjective and Objective Quality 
Assessment of Pansharpened Images".

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

1.The URL of the niqe algorithm referenced by this program is http://live.ece.utexas.edu/research/quality/niqe_release.zip.

2.The feature extraction method can be changed accordingly.